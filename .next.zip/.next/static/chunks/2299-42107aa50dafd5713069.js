"use strict";(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[2299],{37876:function(e,r,t){let i,o,s;t.d(r,{WJ:function(){return i},FJ:function(){return s}}),function(e){e[e.MASTERCHEF=0]="MASTERCHEF",e[e.MASTERCHEF_V2=1]="MASTERCHEF_V2",e[e.MINICHEF=2]="MINICHEF"}(i||(i={})),function(e){e[e.SIMPLE=0]="SIMPLE",e[e.COMPLEX=1]="COMPLEX",e[e.ALCX=2]="ALCX"}(o||(o={})),function(e){e[e.SWAP=0]="SWAP",e[e.KASHI=1]="KASHI"}(s||(s={}))},74601:function(e,r,t){t.d(r,{Z:function(){return b}});var i=t(49361),o=t(67294),s=t(48222),a=t(91231),n=t(91561),c=t(7444),l=t(85893);var d=({isOpen:e,onDismiss:r,children:t})=>(0,l.jsx)(n.u.Root,{show:e,as:o.Fragment,children:(0,l.jsx)(c.V,{as:"div",static:!0,className:"fixed z-10 inset-0 overflow-y-auto",open:e,onClose:r,children:(0,l.jsxs)("div",{className:"relative flex items-center justify-center min-h-screen text-center block",children:[(0,l.jsx)(n.u.Child,{as:o.Fragment,enter:"ease-out duration-100",enterFrom:"opacity-0",enterTo:"opacity-40",leave:"ease-in duration-100",leaveFrom:"opacity-40",leaveTo:"opacity-0",children:(0,l.jsxs)(c.V.Overlay,{className:"fixed inset-0 bg-black bg-opacity-40 transition backdrop-filter backdrop-blur-[3px] backdrop-opacity-100",children:[(0,l.jsx)("div",{className:"fixed inset-0 mb-[20vw] ml-auto bg-pink bg-opacity-40 w-[60vw] rounded-full z-0 filter blur-[400px] rounded-full"}),(0,l.jsx)("div",{className:"fixed inset-0 mt-[20vw] mr-auto bg-blue bg-opacity-40 w-[60vw] rounded-full z-0 filter blur-[400px] rounded-full"})]})}),(0,l.jsx)("span",{className:"inline-block align-middle h-screen","aria-hidden":"true",children:"\u200b"}),(0,l.jsx)(n.u.Child,{as:o.Fragment,enter:"ease-out duration-100",enterFrom:"opacity-0",enterTo:"opacity-40",leave:"ease-in duration-100",leaveFrom:"opacity-40",leaveTo:"opacity-0",children:(0,l.jsx)("div",{className:"inline-block align-bottom rounded-lg text-left overflow-hidden transform  sm:my-8 sm:align-middle max-w-sm md:max-w-3xl sm:w-full p-4 sm:p-6",children:t})})]})})}),u=t(25675),h=t(23233),k=t(78828),p=t(63130),$=t(49552),y=t.n($),f=t(47662);const m=({children:e,networks:r=[]})=>{const{i18n:t}=(0,s.mV)(),{chainId:n,library:c,account:$}=(0,f.aQ)(),m=(0,l.jsx)(h.Z,{href:"/swap",children:(0,l.jsx)("a",{className:"text-blue focus:outline-none",children:t._(t._("home page"))})});return(0,l.jsxs)(l.Fragment,{children:[(0,l.jsx)(d,{isOpen:!!$&&!r.includes(n),onDismiss:()=>null,children:(0,l.jsxs)("div",{className:"flex flex-col gap-7 justify-center",children:[(0,l.jsx)(p.Z,{variant:"h1",className:"max-w-2xl text-white text-center",weight:700,children:t._(t._("Roll it back - this feature is not yet supported on {0}.",{0:i.z[n]}))}),(0,l.jsx)(p.Z,{className:"text-center",children:(0,l.jsx)(s.cC,{id:"Either return to the {link}, or change to an available network.",values:{link:m},components:o.Fragment})}),(0,l.jsx)(p.Z,{className:"uppercase text-white text-center text-lg tracking-[.2rem]",weight:700,children:t._(t._("Available Networks"))}),(0,l.jsx)("div",{className:`grid gap-5 md:gap-10 md:grid-cols-[${Math.min(6,r.length)}] grid-cols-[${Math.min(3,r.length)}]`,children:r.map(((e,r)=>(0,l.jsxs)("button",{className:"text-primary hover:text-white flex items-center flex-col gap-2 justify-start",onClick:()=>{const r=k.b[e];y().set("chainId",e),e===a.a_.MAINNET?null===c||void 0===c||c.send("wallet_switchEthereumChain",[{chainId:"0x1"},$]):null===c||void 0===c||c.send("wallet_addEthereumChain",[r,$])},children:[(0,l.jsx)("div",{className:"w-[40px] h-[40px]",children:(0,l.jsx)(u.default,{src:i.w[e],alt:"Switch Network",className:"rounded-md filter drop-shadow-currencyLogo",width:"40px",height:"40px"})}),(0,l.jsx)(p.Z,{className:"text-sm",children:i.z[e]})]},r)))})]})}),e]})};var b=e=>({children:r})=>(0,l.jsx)(m,{networks:e,children:r})},8012:function(e,r,t){t.d(r,{Te:function(){return Q},rL:function(){return R},Bh:function(){return V},NO:function(){return Y},HF:function(){return J},M1:function(){return G},ME:function(){return K},Fb:function(){return X},it:function(){return L},__:function(){return W},W:function(){return z}});var i=t(92809),o=t(28687),s=t(88360);const a=s.ZP`
  fragment blockFields on Block {
    id
    number
    timestamp
  }
`,n=s.ZP`
  query blockQuery($where: Block_filter) {
    blocks(first: 1, orderBy: timestamp, orderDirection: desc, where: $where) {
      ...blockFields
    }
  }
  ${a}
`,c=s.ZP`
  query blocksQuery($first: Int! = 1000, $skip: Int! = 0, $start: Int!, $end: Int!) {
    blocks(
      first: $first
      skip: $skip
      orderBy: number
      orderDirection: desc
      where: { timestamp_gt: $start, timestamp_lt: $end }
    ) {
      ...blockFields
    }
  }
  ${a}
`,l=(s.ZP`
  query factoryQuery($block: Block_height) {
    factories(first: 1, block: $block) {
      id
      volumeUSD
      liquidityUSD
    }
  }
`,s.ZP`
  query userIdsQuery($first: Int! = 1000, $skip: Int! = 0) {
    users(first: $first, skip: $skip) {
      id
    }
  }
`,s.ZP`
  query uniswapUserQuery($id: String!) {
    uniswapUser: user(id: $id) {
      id
      liquidityPositions {
        id
        liquidityTokenBalance
        # historicalSnapshots {
        #   id
        #   reserve0
        #   reserve1
        #   block
        #   timestamp
        #   liquidityTokenBalance
        #   liquidityTokenTotalSupply
        # }
      }
    }
  }
`,s.ZP`
  fragment bundleFields on Bundle {
    id
    ethPrice
  }
`),d=s.ZP`
  query ethPriceQuery($id: Int! = 1, $block: Block_height) {
    bundles(id: $id, block: $block) {
      ...bundleFields
    }
  }
  ${l}
`,u=s.ZP`
  query tokenPriceQuery($id: String!) {
    token(id: $id) {
      id
      derivedETH
    }
  }
`,h=s.ZP`
  fragment dayDataFields on DayData {
    id
    date
    volumeETH
    volumeUSD
    untrackedVolume
    liquidityETH
    liquidityUSD
    txCount
  }
`,k=(s.ZP`
  query dayDatasQuery($first: Int! = 1000, $date: Int! = 0, $where: DayData_filter) {
    dayDatas(first: $first, orderBy: date, orderDirection: desc, where: $where) {
      ...dayDataFields
    }
  }
  ${h}
`,s.ZP`
  fragment pairFields on Pair {
    id
    reserveUSD
    reserveETH
    volumeUSD
    untrackedVolumeUSD
    trackedReserveETH
    token0 {
      ...PairToken
    }
    token1 {
      ...PairToken
    }
    reserve0
    reserve1
    token0Price
    token1Price
    totalSupply
    txCount
    timestamp
  }
  fragment PairToken on Token {
    id
    name
    symbol
    totalSupply
    derivedETH
  }
`),p=(s.ZP`
  query pairQuery($id: String!, $block: Block_height) {
    pair(id: $id, block: $block) {
      ...pairFields
    }
  }
  ${k}
`,s.ZP`
  query pairIdsQuery($skip: Int) {
    pairs(first: 1000, skip: $skip) {
      id
    }
  }
`,s.ZP`
  query pairCountQuery {
    uniswapFactories {
      pairCount
    }
  }
`,s.ZP`
  query pairDayDatasQuery($first: Int = 1000, $skip: Int, $date: Int = 0, $pairs: [Bytes]!) {
    pairDayDatas(
      first: $first
      skip: $skip
      orderBy: date
      orderDirection: desc
      where: { pair_in: $pairs, date_gt: $date }
    ) {
      date
      pair {
        id
      }
      token0 {
        derivedETH
      }
      token1 {
        derivedETH
      }
      reserveUSD
      volumeToken0
      volumeToken1
      volumeUSD
      txCount
    }
  }
`,s.ZP`
  query liquidityPositionSubsetQuery($first: Int! = 1000, $skip: Int, $where: LiquidityPosition_filter) {
    liquidityPositions(first: $first, skip: $skip, where: $where) {
      id
      liquidityTokenBalance
      user {
        id
      }
      pair {
        id
      }
    }
  }
`,s.ZP`
  query pair(
    $skip: Int = 0
    $first: Int = 1000
    $where: Pair_filter
    $block: Block_height
    $orderBy: Pair_orderBy = "trackedReserveETH"
    $orderDirection: OrderDirection = "desc"
  ) {
    pairs(
      skip: $skip
      first: $first
      orderBy: $orderBy
      orderDirection: $orderDirection
      block: $block
      where: $where
    ) {
      ...pairFields
    }
  }
  ${k}
`),$=(s.ZP`
  query pairsTimeTravelQuery($first: Int! = 1000, $pairAddresses: [Bytes]!, $block: Block_height!) {
    pairs(
      first: $first
      block: $block
      orderBy: trackedReserveETH
      orderDirection: desc
      where: { id_in: $pairAddresses }
    ) {
      id
      reserveUSD
      trackedReserveETH
      volumeUSD
      untrackedVolumeUSD
      txCount
    }
  }
`,s.ZP`
  fragment tokenFields on Token {
    id
    symbol
    name
    decimals
    totalSupply
    volume
    volumeUSD
    untrackedVolumeUSD
    txCount
    liquidity
    derivedETH
  }
`),y=(s.ZP`
  query tokenQuery($id: String!, $block: Block_height) {
    token(id: $id, block: $block) {
      ...tokenFields
    }
  }
  ${$}
`,s.ZP`
  query tokenIdsQuery($skip: Int) {
    tokens(first: 1000, skip: $skip) {
      id
    }
  }
`,s.ZP`
  query tokenDayDatasQuery($first: Int! = 1000, $skip: Int, $block: Block_height, $where: TokenDayData_filter) {
    tokenDayDatas(first: $first, skip: $skip, orderBy: date, orderDirection: desc, where: $where, block: $block) {
      id
      date
      token {
        id
      }
      volumeUSD
      liquidityUSD
      priceUSD
      txCount
    }
  }
`,s.ZP`
  query tokenPairsQuery($id: String!, $skip: Int, $block: Block_height) {
    pairs0: pairs(
      first: 1000
      skip: $skip
      orderBy: reserveUSD
      orderDirection: desc
      where: { token0: $id }
      block: $block
    ) {
      ...pairFields
    }
    pairs1: pairs(
      first: 1000
      skip: $skip
      orderBy: reserveUSD
      orderDirection: desc
      where: { token1: $id }
      block: $block
    ) {
      ...pairFields
    }
  }
  ${k}
`,s.ZP`
  query tokensQuery($first: Int! = 1000, $skip: Int, $block: Block_height, $where: Token_filter) {
    tokens(first: $first, skip: $skip, orderBy: volumeUSD, orderDirection: desc, block: $block, where: $where) {
      ...tokenFields
      dayData(first: 7, orderBy: date, orderDirection: desc) {
        id
        priceUSD
        date
      }
    }
  }
  ${$}
`,s.ZP`
  query tokenSubsetQuery(
    $first: Int! = 1000
    $skip: Int
    $tokenAddresses: [Bytes]!
    $orderBy: String! = "id"
    $orderDirection: String! = "desc"
    $block: Block_height
  ) {
    tokens(
      first: $first
      skip: $skip
      orderBy: $orderBy
      orderDirection: $orderDirection
      where: { id_in: $tokenAddresses }
      block: $block
    ) {
      ...tokenFields
    }
  }
  ${$}
`,s.ZP`
  query transactionsQuery($first: Int! = 1000, $skip: Int, $block: Block_height, $where: Swap_filter) {
    swaps(orderBy: timestamp, orderDirection: desc, where: $where) {
      id
      timestamp
      pair {
        token0 {
          symbol
        }
        token1 {
          symbol
        }
      }
      sender
      amount0In
      amount0Out
      amount1In
      amount1Out
      amountUSD
      to
    }
    mints(orderBy: timestamp, orderDirection: desc, where: $where) {
      id
      timestamp
      pair {
        token0 {
          symbol
        }
        token1 {
          symbol
        }
      }
      sender
      amount0
      amount1
      amountUSD
      to
    }
    burns(orderBy: timestamp, orderDirection: desc, where: $where) {
      id
      timestamp
      pair {
        token0 {
          symbol
        }
        token1 {
          symbol
        }
      }
      sender
      amount0
      amount1
      amountUSD
      to
    }
  }
`,s.ZP`
  query poolsQuery(
    $first: Int! = 1000
    $skip: Int! = 0
    $orderBy: String! = "id"
    $orderDirection: String! = "desc"
    $block: Block_height
    $where: Pool_filter! = { allocPoint_gt: 0, accSushiPerShare_gt: 0 }
  ) {
    pools(
      first: $first
      skip: $skip
      orderBy: $orderBy
      orderDirection: $orderDirection
      block: $block
      where: $where
    ) {
      id
      pair
      allocPoint
      lastRewardBlock
      accSushiPerShare
      balance
      userCount
      owner {
        id
        sushiPerBlock
        totalAllocPoint
      }
    }
  }
`,s.ZP`
  query masterChefV1PairAddresses(
    $first: Int! = 1000
    $skip: Int! = 0
    $orderBy: String! = "id"
    $orderDirection: String! = "desc"
    $where: Pool_filter! = { allocPoint_gt: 0, accSushiPerShare_gt: 0 }
  ) {
    pools(first: $first, skip: $skip, orderBy: $orderBy, orderDirection: $orderDirection, where: $where) {
      id
      allocPoint
      accSushiPerShare
      pair {
        id
      }
    }
  }
`,s.ZP`
  query masterChefV1TotalAllocPoint($id: String! = "0xc2edad668740f1aa35e4d8f227fb8e17dca888cd") {
    masterChef(id: $id) {
      id
      totalAllocPoint
    }
  }
`);s.ZP`
  query masterChefV1SushiPerBlock($id: String! = "0xc2edad668740f1aa35e4d8f227fb8e17dca888cd") {
    masterChef(id: $id) {
      id
      sushiPerBlock
    }
  }
`,s.ZP`
  query poolsV2Query(
    $first: Int! = 1000
    $skip: Int! = 0
    $orderBy: String! = "id"
    $orderDirection: String! = "desc"
    $block: Block_height
    $where: Pool_filter! = { allocPoint_gt: 0 }
  ) {
    pools(
      first: $first
      skip: $skip
      orderBy: $orderBy
      orderDirection: $orderDirection
      block: $block
      where: $where
    ) {
      id
      pair
      allocPoint
      slpBalance
      masterChef {
        id
        totalAllocPoint
      }
      rewarder {
        id
        rewardToken
        rewardPerSecond
      }
    }
  }
`,s.ZP`
  query masterChefV2PairAddresses(
    $first: Int! = 1000
    $skip: Int! = 0
    $orderBy: String! = "id"
    $orderDirection: String! = "desc"
    $where: Pool_filter! = { allocPoint_gt: 0 }
  ) {
    pools(first: $first, skip: $skip, orderBy: $orderBy, orderDirection: $orderDirection, where: $where) {
      id
      allocPoint
      accSushiPerShare
      pair {
        id
      }
    }
  }
`,s.ZP`
  query miniChefPoolsQuery(
    $first: Int! = 1000
    $skip: Int! = 0
    $orderBy: String! = "id"
    $orderDirection: String! = "desc"
    $block: Block_height
    $where: Pool_filter! = { allocPoint_gt: 0, accSushiPerShare_gt: 0 }
  ) {
    pools(
      first: $first
      skip: $skip
      orderBy: $orderBy
      orderDirection: $orderDirection
      block: $block
      where: $where
    ) {
      id
      pair
      rewarder {
        id
        rewardToken
        rewardPerSecond
      }
      allocPoint
      lastRewardTime
      accSushiPerShare
      slpBalance
      userCount
      miniChef {
        id
        sushiPerSecond
        totalAllocPoint
      }
    }
  }
`,s.ZP`
  query miniChefPairAddresses(
    $first: Int! = 1000
    $skip: Int! = 0
    $orderBy: String! = "id"
    $orderDirection: String! = "desc"
    $where: Pool_filter! = { allocPoint_gt: 0, accSushiPerShare_gt: 0 }
  ) {
    pools(first: $first, skip: $skip, orderBy: $orderBy, orderDirection: $orderDirection, where: $where) {
      id
      allocPoint
      accSushiPerShare
      pair {
        id
      }
    }
  }
`;var f=t(12383),m=t(99982),b=t(88330),w=t(91231);const P="https://api.thegraph.com",g="https://q.hg.network",_={[w.a_.MAINNET]:P,[w.a_.XDAI]:P,[w.a_.MATIC]:P,[w.a_.FANTOM]:P,[w.a_.BSC]:P,[w.a_.AVALANCHE]:P,[w.a_.CELO]:P,[w.a_.ARBITRUM]:P,[w.a_.HARMONY]:"https://sushi.graph.t.hmny.io",[w.a_.OKEX]:g,[w.a_.HECO]:g},S={[w.a_.MAINNET]:"blocklytics/ethereum-blocks",[w.a_.XDAI]:"matthewlilley/xdai-blocks",[w.a_.MATIC]:"matthewlilley/polygon-blocks",[w.a_.FANTOM]:"matthewlilley/fantom-blocks",[w.a_.BSC]:"matthewlilley/bsc-blocks",[w.a_.HARMONY]:"sushiswap/harmony-blocks",[w.a_.AVALANCHE]:"matthewlilley/avalanche-blocks",[w.a_.CELO]:"sushiswap/celo-blocks",[w.a_.ARBITRUM]:"sushiswap/arbitrum-blocks",[w.a_.OKEX]:"okexchain-blocks/oec",[w.a_.HECO]:"hecoblocks/heco"},v=async(e=w.a_.MAINNET,r,t)=>(0,o.request)(`${_[e]}/subgraphs/name/${S[e]}`,r,t),I=async(e=w.a_.MAINNET)=>{const r=(0,f.Z)(Date.now()),t=(0,m.Z)((0,b.Z)(r,6)),i=(0,m.Z)(r),o=await(async(e=w.a_.MAINNET,r,t)=>{const{blocks:i}=await v(e,c,{start:r,end:t});return i})(e,t,i);return null===o||void 0===o?void 0:o.reduce(((e,r,t)=>{if(e.timestamp){const t=e.timestamp-r.timestamp;e.averageBlockTime=e.averageBlockTime+t}return e.timestamp=r.timestamp,t===o.length-1?e.averageBlockTime/o.length:e}),{timestamp:null,averageBlockTime:0})};function D(e,r){var t=Object.keys(e);if(Object.getOwnPropertySymbols){var i=Object.getOwnPropertySymbols(e);r&&(i=i.filter((function(r){return Object.getOwnPropertyDescriptor(e,r).enumerable}))),t.push.apply(t,i)}return t}function B(e){for(var r=1;r<arguments.length;r++){var t=null!=arguments[r]?arguments[r]:{};r%2?D(Object(t),!0).forEach((function(r){(0,i.Z)(e,r,t[r])})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(t)):D(Object(t)).forEach((function(r){Object.defineProperty(e,r,Object.getOwnPropertyDescriptor(t,r))}))}return e}const x={[w.a_.MAINNET]:"sushiswap/exchange",[w.a_.XDAI]:"sushiswap/xdai-exchange",[w.a_.MATIC]:"sushiswap/matic-exchange",[w.a_.FANTOM]:"sushiswap/fantom-exchange",[w.a_.BSC]:"sushiswap/bsc-exchange",[w.a_.HARMONY]:"sushiswap/harmony-exchange",[w.a_.OKEX]:"sushiswap/okex-exchange",[w.a_.AVALANCHE]:"sushiswap/avalanche-exchange",[w.a_.CELO]:"sushiswap/celo-exchange",[w.a_.ARBITRUM]:"sushiswap/arbitrum-exchange",[w.a_.OKEX]:"okex-exchange/oec",[w.a_.HECO]:"heco-exchange/heco"},T=async(e=w.a_.MAINNET,r,t={})=>async function(e,r,t={}){if(e.includes("undefined"))return{};let i={},s=0,a=!0;for(;a;){a=!1;const n=await(0,o.request)(e,r,t);if(Object.keys(n).forEach((e=>{i[e]=i[e]?[...i[e],...n[e]]:n[e]})),Object.values(n).forEach((e=>{1e3===e.length&&(a=!0)})),Object.keys(t).includes("first"))break;s+=1e3,t=Z(Z({},t),{},{skip:s})}return i}(`${_[e]}/subgraphs/name/${x[e]}`,r,t),A=async(e=w.a_.MAINNET,r,t)=>{const i=await N(e),{token:o}=await T(e,r,t);return(null===o||void 0===o?void 0:o.derivedETH)*i},N=async(e=w.a_.MAINNET,r)=>{var t;const i=await E(e,void 0,r);return null===i||void 0===i||null===(t=i.bundles[0])||void 0===t?void 0:t.ethPrice},E=async(e=w.a_.MAINNET,r=d,t={id:1})=>T(e,r,t);w.a_.MATIC,w.a_.XDAI,w.a_.HARMONY,w.a_.ARBITRUM,w.a_.MAINNET,w.a_.MAINNET;const O=async(e,r=w.a_.MAINNET,t)=>(0,o.request)("https://api.thegraph.com/subgraphs/name/agelesszeal/icp-masterchef",e,t);function C(e,r){var t=Object.keys(e);if(Object.getOwnPropertySymbols){var i=Object.getOwnPropertySymbols(e);r&&(i=i.filter((function(r){return Object.getOwnPropertyDescriptor(e,r).enumerable}))),t.push.apply(t,i)}return t}function Z(e){for(var r=1;r<arguments.length;r++){var t=null!=arguments[r]?arguments[r]:{};r%2?C(Object(t),!0).forEach((function(r){(0,i.Z)(e,r,t[r])})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(t)):C(Object(t)).forEach((function(r){Object.defineProperty(e,r,Object.getOwnPropertyDescriptor(t,r))}))}return e}var M=t(67294),j=t(52503),F=(t(37876),t(57043),t(28269));const q=s.ZP`
  fragment bentoTokenFields on Token {
    id
    # bentoBox
    name
    symbol
    decimals
    totalSupplyElastic
    totalSupplyBase
    block
    timestamp
  }
`,U=(s.ZP`
  query bentoUserTokens($user: String!, $skip: Int = 0, $first: Int = 1000, $block: Block_height) {
    userTokens(skip: $skip, first: $first, block: $block, where: { share_gt: 0, user: $user }) {
      token {
        ...bentoTokenFields
      }
      share
    }
  }
  ${q}
`,s.ZP`
  fragment kashiPairFields on KashiPair {
    id
    # bentoBox
    type
    masterContract
    owner
    feeTo
    name
    symbol
    oracle
    asset {
      ...bentoTokenFields
    }
    collateral {
      ...bentoTokenFields
    }
    exchangeRate
    totalAssetElastic
    totalAssetBase
    totalCollateralShare
    totalBorrowElastic
    totalBorrowBase
    interestPerSecond
    utilization
    feesEarnedFraction
    totalFeesEarnedFraction
    lastAccrued
    supplyAPR
    borrowAPR
    # transactions
    # users
    block
    timestamp
  }
  ${q}
`);s.ZP`
  query kashiPairs(
    $skip: Int = 0
    $first: Int = 1000
    $where: KashiPair_filter
    $block: Block_height
    $orderBy: KashiPair_orderBy = "utilization"
    $orderDirection: OrderDirection! = "desc"
  ) {
    kashiPairs(
      skip: $skip
      first: $first
      where: $where
      block: $block
      orderBy: $orderBy
      orderDirection: $orderDirection
    ) {
      ...kashiPairFields
    }
  }
  ${U}
`,s.ZP`
  query kashiUserPairs($user: String!, $skip: Int = 0, $first: Int = 1000, $block: Block_height) {
    userKashiPairs(skip: $skip, first: $first, block: $block, where: { user: $user }) {
      assetFraction
      collateralShare
      borrowPart
      pair {
        ...kashiPairFields
      }
    }
  }
  ${U}
`,s.ZP`
  query bentoBoxQuery(
    $id: String! = "0xf5bce5077908a1b7370b9ae04adc565ebd643966"
    $block: Block_height
    $where: BentoBox_filter
  ) {
    bentoBoxes(first: 1, block: $block, where: $where) {
      id
      totalUsers
      totalTokens
      totalKashiPairs
      tokens(first: 1000) {
        id
        name
        symbol
        decimals
        totalSupplyBase
        totalSupplyElastic
      }
    }
  }
`;t(97735);w.a_.MAINNET,w.a_.XDAI,w.a_.MATIC,w.a_.FANTOM,w.a_.BSC,w.a_.ARBITRUM;var H=t(47662);function R({timestamp:e,daysAgo:r,chainId:t,shouldFetch:i=!0},o){i=i&&!!t,e=e?13!==String(e).length?Number(e):Math.floor(Number(e)/1e3):void 0,e=(0,M.useMemo)((()=>r?Math.floor(Date.now()/1e3)-86400*r:e),[r]);const{data:s}=(0,j.ZP)(i?["block",t,e]:null,((e,r,t)=>(async(e=w.a_.MAINNET,r)=>{var t;const{blocks:i}=await v(e,n,r?{where:{timestamp_gt:r-600,timestamp_lt:r}}:{});return Number(null===i||void 0===i||null===(t=i[0])||void 0===t?void 0:t.number)})(r,t)),o);return s}function Q(e){const{chainId:r}=(0,H.aQ)(),{data:t}=(0,j.ZP)(r?["averageBlockTime",r]:null,((e,r)=>I(r)),e);return t}t(81986);function V(e,r){const{data:t}=(0,j.ZP)(["ethPrice",JSON.stringify(e)],(()=>(async e=>N(w.a_.MAINNET,e))(e)),r);return t}function L(e,r){const{data:t}=(0,j.ZP)(["stakePrice",JSON.stringify(e)],(()=>(async(e={})=>A(w.a_.XDAI,u,B({id:"0xb7d311e2eb55f2f68a9440da38e7989210b9a05e"},e)))(e)),r);return t}function X(e,r){const{data:t}=(0,j.ZP)(["onePrice",JSON.stringify(e)],(()=>(async e=>N(w.a_.HARMONY,e))(e)),r);return t}function K(e,r){const{data:t}=(0,j.ZP)(["maticPrice",JSON.stringify(e)],(()=>(async(e={})=>A(w.a_.MATIC,u,B({id:"0x0d500b1d8e8ef31e21c99d1db9a6444d3adf1270"},e)))(e)),r);return t}function z(e,r){const{data:t}=(0,j.ZP)(["sushiPrice",JSON.stringify(e)],(()=>(async(e={})=>A(w.a_.MAINNET,u,B({id:"0x6b3595068778dd592e39a122f4f5a5cf09c90fe2"},e)))(e)),r);return t}function J(e,r){return.1445}function Y(e,r){return.02079}function W({timestamp:e,block:r,chainId:t,shouldFetch:i=!0,user:o,subset:s},a){var n;const c=R({timestamp:e,chainId:t,shouldFetch:i&&!!e});i=i&&!!t;const l={block:(r=null!==(n=r)&&void 0!==n?n:e?c:void 0)?{number:r}:void 0,where:{user:null===o||void 0===o?void 0:o.toLowerCase(),id_in:null===s||void 0===s?void 0:s.map((e=>e.toLowerCase()))}},{data:d}=(0,j.ZP)(i?["sushiPairs",t,JSON.stringify(l)]:null,((e,r)=>(async(e=w.a_.MAINNET,r,t=p)=>{const{pairs:i}=await T(e,t,r);return i})(r,l)),a);return d}function G(e){const{chainId:r}=(0,F.Z)(),t=r&&r===w.a_.MAINNET,{data:i}=(0,j.ZP)(t?"masterChefV1TotalAllocPoint":null,(()=>(async()=>{const{masterChef:{totalAllocPoint:e}}=await O(y);return e})()),e);return i}}}]);
//# sourceMappingURL=2299-42107aa50dafd5713069.js.map
"use strict";
exports.id = 4703;
exports.ids = [4703];
exports.modules = {

/***/ 3302:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "E": () => (/* binding */ getExplorerLink)
/* harmony export */ });
/* harmony import */ var _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6766);
/* harmony import */ var _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__);

const explorers = {
  etherscan: (link, data, type) => {
    switch (type) {
      case 'transaction':
        return `${link}/tx/${data}`;

      default:
        return `${link}/${type}/${data}`;
    }
  },
  blockscout: (link, data, type) => {
    switch (type) {
      case 'transaction':
        return `${link}/tx/${data}`;

      case 'token':
        return `${link}/tokens/${data}`;

      default:
        return `${link}/${type}/${data}`;
    }
  },
  harmony: (link, data, type) => {
    switch (type) {
      case 'transaction':
        return `${link}/tx/${data}`;

      case 'token':
        return `${link}/address/${data}`;

      default:
        return `${link}/${type}/${data}`;
    }
  },
  okex: (link, data, type) => {
    switch (type) {
      case 'transaction':
        return `${link}/tx/${data}`;

      case 'token':
        return `${link}/tokenAddr/${data}`;

      default:
        return `${link}/${type}/${data}`;
    }
  }
};
const chains = {
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET]: {
    link: 'https://etherscan.io',
    builder: explorers.etherscan
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.ROPSTEN]: {
    link: 'https://ropsten.etherscan.io',
    builder: explorers.etherscan
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.RINKEBY]: {
    link: 'https://rinkeby.etherscan.io',
    builder: explorers.etherscan
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId["GÖRLI"]]: {
    link: 'https://goerli.etherscan.io',
    builder: explorers.etherscan
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.KOVAN]: {
    link: 'https://kovan.etherscan.io',
    builder: explorers.etherscan
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MATIC]: {
    link: 'https://polygonscan.com',
    builder: explorers.etherscan
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MATIC_TESTNET]: {
    link: 'https://mumbai.polygonscan.com',
    builder: explorers.etherscan
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.FANTOM]: {
    link: 'https://ftmscan.com',
    builder: explorers.etherscan
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.FANTOM_TESTNET]: {
    link: 'https://testnet.ftmscan.com',
    builder: explorers.etherscan
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.XDAI]: {
    link: 'https://blockscout.com/xdai/mainnet',
    builder: explorers.blockscout
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.BSC]: {
    link: 'https://bscscan.com',
    builder: explorers.etherscan
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.BSC_TESTNET]: {
    link: 'https://testnet.bscscan.com',
    builder: explorers.etherscan
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.ARBITRUM]: {
    link: 'https://arbiscan.io',
    builder: explorers.etherscan
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MOONBEAM_TESTNET]: {
    link: 'https://moonbeam-explorer.netlify.app',
    builder: explorers.blockscout
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.AVALANCHE]: {
    link: 'https://cchain.explorer.avax.network',
    builder: explorers.blockscout
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.AVALANCHE_TESTNET]: {
    link: 'https://cchain.explorer.avax-test.network',
    builder: explorers.etherscan
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HECO]: {
    link: 'https://hecoinfo.com',
    builder: explorers.etherscan
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HECO_TESTNET]: {
    link: 'https://testnet.hecoinfo.com',
    builder: explorers.etherscan
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HARMONY]: {
    link: 'https://beta.explorer.harmony.one/#',
    builder: explorers.harmony
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HARMONY_TESTNET]: {
    link: 'https://explorer.pops.one/#',
    builder: explorers.harmony
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.OKEX]: {
    link: 'https://www.oklink.com/okexchain',
    builder: explorers.okex
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.OKEX_TESTNET]: {
    link: 'https://www.oklink.com/okexchain-test',
    builder: explorers.okex
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.CELO]: {
    link: 'https://explorer.celo.org',
    builder: explorers.blockscout
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.PALM]: {
    link: '',
    // ??
    builder: explorers.blockscout
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MOONRIVER]: {
    link: 'https://blockscout.moonriver.moonbeam.network',
    builder: explorers.blockscout
  }
};
function getExplorerLink(chainId, data, type) {
  const chain = chains[chainId];
  return chain.builder(chain.link, data, type);
}

/***/ }),

/***/ 451:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ useDebounce)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
 // modified from https://usehooks.com/useDebounce/

function useDebounce(value, delay) {
  const {
    0: debouncedValue,
    1: setDebouncedValue
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(value);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    // Update debounced value after delay
    const handler = setTimeout(() => {
      setDebouncedValue(value);
    }, delay); // Cancel the timeout if value changes (also on delay change or unmount)
    // This is how we prevent debounced value from updating if value is changed ...
    // .. within the delay period. Timeout gets cleared and restarted.

    return () => {
      clearTimeout(handler);
    };
  }, [value, delay]);
  return debouncedValue;
}

/***/ })

};
;
//# sourceMappingURL=4703.js.map
"use strict";
exports.id = 4576;
exports.ids = [4576];
exports.modules = {

/***/ 8561:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Dots)
/* harmony export */ });
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3289);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _functions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7735);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);





function Dots({
  children = /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("span", {}),
  className
}) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.Fragment, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx((styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default()), {
      id: "106137454",
      children: [".dots.jsx-106137454::after{content:'.';}"]
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("span", {
      className: "jsx-106137454" + " " + ((0,_functions__WEBPACK_IMPORTED_MODULE_1__/* .classNames */ .AK)('after:inline-block dots after:animate-ellipsis after:w-4 after:text-left', className) || ""),
      children: children
    })]
  });
}

/***/ }),

/***/ 1986:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "L0": () => (/* binding */ Feature),
/* harmony export */   "vR": () => (/* binding */ featureEnabled)
/* harmony export */ });
/* unused harmony export chainsWithFeature */
/* harmony import */ var _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6766);
/* harmony import */ var _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__);

let Feature;

(function (Feature) {
  Feature["AMM"] = "AMM";
  Feature["AMM_V2"] = "AMM V2";
  Feature["LIQUIDITY_MINING"] = "Liquidity Mining";
  Feature["BENTOBOX"] = "BentoBox";
  Feature["KASHI"] = "Kashi";
  Feature["MISO"] = "MISO";
  Feature["ANALYTICS"] = "Analytics";
  Feature["MIGRATE"] = "Migrate";
  Feature["STAKING"] = "Staking";
})(Feature || (Feature = {}));

const features = {
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MAINNET]: [Feature.AMM, Feature.LIQUIDITY_MINING, Feature.BENTOBOX, Feature.KASHI, Feature.MIGRATE, Feature.ANALYTICS, Feature.STAKING, Feature.MISO],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.ROPSTEN]: [Feature.AMM, Feature.LIQUIDITY_MINING, Feature.BENTOBOX, Feature.KASHI],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.RINKEBY]: [Feature.AMM, Feature.LIQUIDITY_MINING, Feature.BENTOBOX, Feature.KASHI],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId["GÖRLI"]]: [Feature.AMM, Feature.LIQUIDITY_MINING, Feature.BENTOBOX, Feature.KASHI],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.KOVAN]: [Feature.AMM, Feature.LIQUIDITY_MINING, Feature.BENTOBOX, Feature.KASHI],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.BSC]: [Feature.AMM, Feature.BENTOBOX, Feature.KASHI, Feature.MIGRATE, Feature.ANALYTICS],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.BSC_TESTNET]: [Feature.AMM],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.FANTOM]: [Feature.AMM, Feature.ANALYTICS],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.FANTOM_TESTNET]: [Feature.AMM],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MATIC]: [Feature.AMM, Feature.LIQUIDITY_MINING, Feature.BENTOBOX, Feature.KASHI, Feature.MIGRATE, Feature.ANALYTICS, Feature.STAKING],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MATIC_TESTNET]: [Feature.AMM],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HARMONY]: [Feature.AMM, Feature.LIQUIDITY_MINING, Feature.ANALYTICS],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.HARMONY_TESTNET]: [Feature.AMM],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.AVALANCHE]: [Feature.AMM, Feature.BENTOBOX, Feature.KASHI],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.AVALANCHE_TESTNET]: [Feature.AMM],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.OKEX]: [Feature.AMM],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.OKEX_TESTNET]: [Feature.AMM],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.XDAI]: [Feature.AMM, Feature.LIQUIDITY_MINING, Feature.ANALYTICS, Feature.BENTOBOX, Feature.KASHI],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.MOONRIVER]: [Feature.AMM],
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.ChainId.ARBITRUM]: [Feature.AMM, Feature.LIQUIDITY_MINING, Feature.ANALYTICS, Feature.BENTOBOX, Feature.KASHI]
};
function featureEnabled(feature, chainId) {
  var _features$chainId;

  return features === null || features === void 0 ? void 0 : (_features$chainId = features[chainId]) === null || _features$chainId === void 0 ? void 0 : _features$chainId.includes(feature);
}
function chainsWithFeature(feature) {
  return Object.keys(features).filter(chain => features[chain].includes(feature)).map(chain => ChainId[chain]);
}

/***/ })

};
;
//# sourceMappingURL=4576.js.map
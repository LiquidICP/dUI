"use strict";
exports.id = 8828;
exports.ids = [8828];
exports.modules = {

/***/ 8828:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "b": () => (/* binding */ SUPPORTED_NETWORKS),
/* harmony export */   "Z": () => (/* binding */ NetworkModal)
/* harmony export */ });
/* harmony import */ var _config_networks__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9361);
/* harmony import */ var _state_application_hooks__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4663);
/* harmony import */ var _state_application_actions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(434);
/* harmony import */ var _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6766);
/* harmony import */ var _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9260);
/* harmony import */ var _components_Modal__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1441);
/* harmony import */ var _components_ModalHeader__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7144);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var cookie_cutter__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8760);
/* harmony import */ var cookie_cutter__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(cookie_cutter__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8269);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__);












const SUPPORTED_NETWORKS = {
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_3__.ChainId.MAINNET]: {
    chainId: '0x1',
    chainName: 'Ethereum',
    nativeCurrency: {
      name: 'Ethereum',
      symbol: 'ETH',
      decimals: 18
    },
    rpcUrls: ['https://mainnet.infura.io/v3'],
    blockExplorerUrls: ['https://etherscan.com']
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_3__.ChainId.FANTOM]: {
    chainId: '0xfa',
    chainName: 'Fantom',
    nativeCurrency: {
      name: 'Fantom',
      symbol: 'FTM',
      decimals: 18
    },
    rpcUrls: ['https://rpcapi.fantom.network'],
    blockExplorerUrls: ['https://ftmscan.com']
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_3__.ChainId.BSC]: {
    chainId: '0x38',
    chainName: 'Binance Smart Chain',
    nativeCurrency: {
      name: 'Binance Coin',
      symbol: 'BNB',
      decimals: 18
    },
    rpcUrls: ['https://bsc-dataseed.binance.org'],
    blockExplorerUrls: ['https://bscscan.com']
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_3__.ChainId.MATIC]: {
    chainId: '0x89',
    chainName: 'Matic',
    nativeCurrency: {
      name: 'Matic',
      symbol: 'MATIC',
      decimals: 18
    },
    rpcUrls: ['https://rpc-mainnet.maticvigil.com'],
    // ['https://matic-mainnet.chainstacklabs.com/'],
    blockExplorerUrls: ['https://explorer-mainnet.maticvigil.com']
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_3__.ChainId.HECO]: {
    chainId: '0x80',
    chainName: 'Heco',
    nativeCurrency: {
      name: 'Heco Token',
      symbol: 'HT',
      decimals: 18
    },
    rpcUrls: ['https://http-mainnet.hecochain.com'],
    blockExplorerUrls: ['https://hecoinfo.com']
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_3__.ChainId.XDAI]: {
    chainId: '0x64',
    chainName: 'xDai',
    nativeCurrency: {
      name: 'xDai Token',
      symbol: 'xDai',
      decimals: 18
    },
    rpcUrls: ['https://rpc.xdaichain.com'],
    blockExplorerUrls: ['https://blockscout.com/poa/xdai']
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_3__.ChainId.HARMONY]: {
    chainId: '0x63564C40',
    chainName: 'Harmony',
    nativeCurrency: {
      name: 'One Token',
      symbol: 'ONE',
      decimals: 18
    },
    rpcUrls: ['https://api.harmony.one', 'https://s1.api.harmony.one', 'https://s2.api.harmony.one', 'https://s3.api.harmony.one'],
    blockExplorerUrls: ['https://explorer.harmony.one/']
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_3__.ChainId.AVALANCHE]: {
    chainId: '0xA86A',
    chainName: 'Avalanche',
    nativeCurrency: {
      name: 'Avalanche Token',
      symbol: 'AVAX',
      decimals: 18
    },
    rpcUrls: ['https://api.avax.network/ext/bc/C/rpc'],
    blockExplorerUrls: ['https://cchain.explorer.avax.network']
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_3__.ChainId.OKEX]: {
    chainId: '0x42',
    chainName: 'OKEx',
    nativeCurrency: {
      name: 'OKEx Token',
      symbol: 'OKT',
      decimals: 18
    },
    rpcUrls: ['https://exchainrpc.okex.org'],
    blockExplorerUrls: ['https://www.oklink.com/okexchain']
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_3__.ChainId.ARBITRUM]: {
    chainId: '0xA4B1',
    chainName: 'Arbitrum',
    nativeCurrency: {
      name: 'Ethereum',
      symbol: 'ETH',
      decimals: 18
    },
    rpcUrls: ['https://arb1.arbitrum.io/rpc'],
    blockExplorerUrls: ['https://mainnet-arb-explorer.netlify.app']
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_3__.ChainId.CELO]: {
    chainId: '0xA4EC',
    chainName: 'Celo',
    nativeCurrency: {
      name: 'Celo',
      symbol: 'CELO',
      decimals: 18
    },
    rpcUrls: ['https://forno.celo.org'],
    blockExplorerUrls: ['https://explorer.celo.org']
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_3__.ChainId.PALM]: {
    chainId: '0x2A15C308D',
    chainName: 'Palm',
    nativeCurrency: {
      name: 'Palm',
      symbol: 'PALM',
      decimals: 18
    },
    rpcUrls: ['https://palm-mainnet.infura.io/v3/da5fbfafcca14b109e2665290681e267'],
    blockExplorerUrls: ['https://explorer.palm.io']
  },
  [_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_3__.ChainId.MOONRIVER]: {
    chainId: '0x505',
    chainName: 'Moonriver',
    nativeCurrency: {
      name: 'Moonriver',
      symbol: 'MOVR',
      decimals: 18
    },
    rpcUrls: ['https://rpc.moonriver.moonbeam.network'],
    blockExplorerUrls: ['https://blockscout.moonriver.moonbeam.network']
  }
};
function NetworkModal() {
  const {
    chainId,
    library,
    account
  } = (0,_hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_9__/* .useActiveWeb3React */ .a)();
  const networkModalOpen = (0,_state_application_hooks__WEBPACK_IMPORTED_MODULE_1__/* .useModalOpen */ .oL)(_state_application_actions__WEBPACK_IMPORTED_MODULE_2__/* .ApplicationModal.NETWORK */ .Lk.NETWORK);
  const toggleNetworkModal = (0,_state_application_hooks__WEBPACK_IMPORTED_MODULE_1__/* .useNetworkModalToggle */ .o)();
  if (!chainId) return null;
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)(_components_Modal__WEBPACK_IMPORTED_MODULE_5__/* .default */ .Z, {
    isOpen: networkModalOpen,
    onDismiss: toggleNetworkModal,
    maxWidth: 672,
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(_components_ModalHeader__WEBPACK_IMPORTED_MODULE_6__/* .default */ .Z, {
      onClose: toggleNetworkModal,
      title: "Select a Network"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)("div", {
      className: "mb-6 text-lg text-primary",
      children: ["You are currently browsing ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx("span", {
        className: "font-bold text-pink",
        children: "LICP"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx("br", {}), " on the ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx("span", {
        className: "font-bold text-blue",
        children: _config_networks__WEBPACK_IMPORTED_MODULE_0__/* .NETWORK_LABEL */ .z[chainId]
      }), " network"]
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx("div", {
      className: "grid grid-flow-row-dense grid-cols-1 gap-5 overflow-y-auto md:grid-cols-2",
      children: [// ChainId.MAINNET,
      _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_3__.ChainId.MATIC // ChainId.FANTOM,
      // ChainId.ARBITRUM,
      // ChainId.OKEX,
      // ChainId.HECO,
      // ChainId.BSC,
      // ChainId.XDAI,
      // ChainId.HARMONY,
      // ChainId.AVALANCHE,
      // ChainId.CELO,
      // ChainId.PALM,
      // ChainId.MOONRIVER,
      ].map((key, i) => {
        if (chainId === key) {
          return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx("button", {
            className: "w-full col-span-1 p-px rounded bg-gradient-to-r from-blue to-pink",
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)("div", {
              className: "flex items-center w-full h-full p-3 space-x-3 rounded bg-dark-1000",
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(next_image__WEBPACK_IMPORTED_MODULE_4__.default, {
                src: _config_networks__WEBPACK_IMPORTED_MODULE_0__/* .NETWORK_ICON */ .w[key],
                alt: `Switch to ${_config_networks__WEBPACK_IMPORTED_MODULE_0__/* .NETWORK_LABEL */ .z[key]} Network`,
                className: "rounded-md",
                width: "32px",
                height: "32px"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx("div", {
                className: "font-bold text-primary",
                children: _config_networks__WEBPACK_IMPORTED_MODULE_0__/* .NETWORK_LABEL */ .z[key]
              })]
            })
          }, i);
        }

        return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsxs)("button", {
          onClick: () => {
            toggleNetworkModal();
            const params = SUPPORTED_NETWORKS[key];
            cookie_cutter__WEBPACK_IMPORTED_MODULE_8___default().set('chainId', key);

            if (key === _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_3__.ChainId.MAINNET) {
              library === null || library === void 0 ? void 0 : library.send('wallet_switchEthereumChain', [{
                chainId: '0x1'
              }, account]);
            } else {
              library === null || library === void 0 ? void 0 : library.send('wallet_addEthereumChain', [params, account]);
            }
          },
          className: "flex items-center w-full col-span-1 p-3 space-x-3 rounded cursor-pointer bg-dark-800 hover:bg-dark-700",
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx(next_image__WEBPACK_IMPORTED_MODULE_4__.default, {
            src: _config_networks__WEBPACK_IMPORTED_MODULE_0__/* .NETWORK_ICON */ .w[key],
            alt: "Switch Network",
            className: "rounded-md",
            width: "32px",
            height: "32px"
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_10__.jsx("div", {
            className: "font-bold text-primary",
            children: _config_networks__WEBPACK_IMPORTED_MODULE_0__/* .NETWORK_LABEL */ .z[key]
          })]
        }, i);
      })
    })]
  });
}

/***/ })

};
;
//# sourceMappingURL=8828.js.map
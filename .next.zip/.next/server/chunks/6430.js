"use strict";
exports.id = 6430;
exports.ids = [6430];
exports.modules = {

/***/ 4218:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "s": () => (/* binding */ toAmount),
/* harmony export */   "T": () => (/* binding */ toShare)
/* harmony export */ });
function toAmount(token, shares) {
  return shares.mulDiv(token.bentoAmount, token.bentoShare);
}
function toShare(token, amount) {
  return amount.mulDiv(token.bentoShare, token.bentoAmount);
}

/***/ }),

/***/ 6430:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "id": () => (/* binding */ useBentoBalances),
  "B2": () => (/* binding */ useBentoMasterContractAllowed)
});

// UNUSED EXPORTS: useBentoBalance

// EXTERNAL MODULE: external "@sushiswap/sdk"
var sdk_ = __webpack_require__(6766);
// EXTERNAL MODULE: ./src/hooks/useContract.ts + 31 modules
var hooks_useContract = __webpack_require__(6435);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: external "@ethersproject/bignumber"
var bignumber_ = __webpack_require__(1446);
// EXTERNAL MODULE: ./src/constants/abis/erc20.json
var erc20 = __webpack_require__(9638);
// EXTERNAL MODULE: ./src/functions/math.ts
var math = __webpack_require__(9247);
// EXTERNAL MODULE: ./src/functions/kashi.ts
var kashi = __webpack_require__(834);
// EXTERNAL MODULE: external "@ethersproject/address"
var address_ = __webpack_require__(7398);
// EXTERNAL MODULE: ./src/functions/bentobox.ts
var bentobox = __webpack_require__(4218);
// EXTERNAL MODULE: ./src/hooks/useActiveWeb3React.ts
var hooks_useActiveWeb3React = __webpack_require__(8269);
// EXTERNAL MODULE: ./src/hooks/Tokens.ts
var Tokens = __webpack_require__(6269);
// EXTERNAL MODULE: ./src/state/multicall/hooks.ts
var hooks = __webpack_require__(879);
// EXTERNAL MODULE: ./src/state/transactions/hooks.tsx
var transactions_hooks = __webpack_require__(9123);
;// CONCATENATED MODULE: ./src/hooks/useTransactionStatus.ts



// we want the latest one to come first, so return negative if a is after b
function newTransactionsFirst(a, b) {
  return b.addedTime - a.addedTime;
}

const useTransactionStatus_useTransactionStatus = () => {
  const {
    0: pendingTXStatus,
    1: setPendingTXStatus
  } = useState(false); // Determine if change in transactions, if so, run query again

  const allTransactions = useAllTransactions();
  const sortedRecentTransactions = useMemo(() => {
    const txs = Object.values(allTransactions);
    return txs.filter(isTransactionRecent).sort(newTransactionsFirst);
  }, [allTransactions]);
  const pending = sortedRecentTransactions.filter(tx => !tx.receipt).map(tx => tx.hash);
  const hasPendingTransactions = !!pending.length;
  useEffect(() => {
    setPendingTXStatus(hasPendingTransactions);
  }, [hasPendingTransactions]);
  return pendingTXStatus;
};

/* harmony default export */ const hooks_useTransactionStatus = ((/* unused pure expression or super */ null && (useTransactionStatus_useTransactionStatus)));
;// CONCATENATED MODULE: ./src/state/bentobox/hooks.ts
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }














function useBentoBalances() {
  const {
    chainId,
    account
  } = (0,hooks_useActiveWeb3React/* useActiveWeb3React */.a)();
  const boringHelperContract = (0,hooks_useContract/* useBoringHelperContract */.HW)();
  const tokens = (0,Tokens/* useAllTokens */.e_)();
  const weth = sdk_.WNATIVE_ADDRESS[chainId];
  const tokenAddresses = Object.keys(tokens);
  const balanceData = (0,hooks/* useSingleCallResult */.Wk)(boringHelperContract, 'getBalances', [account, tokenAddresses]);
  const uiData = (0,hooks/* useSingleCallResult */.Wk)(boringHelperContract, 'getUIInfo', [account, [], sdk_.USDC_ADDRESS[chainId], [sdk_.KASHI_ADDRESS[chainId]]]); // IERC20 token = addresses[i];
  // balances[i].totalSupply = token.totalSupply();
  // balances[i].token = token;
  // balances[i].balance = token.balanceOf(who);
  // balances[i].bentoAllowance = token.allowance(who, address(bentoBox));
  // balances[i].nonce = token.nonces(who);
  // balances[i].bentoBalance = bentoBox.balanceOf(token, who);
  // (balances[i].bentoAmount, balances[i].bentoShare) = bentoBox.totals(token);
  // balances[i].rate = getETHRate(token);

  return (0,external_react_.useMemo)(() => {
    if (uiData.loading || balanceData.loading || uiData.error || balanceData.error || !uiData.result || !balanceData.result) return [];
    return tokenAddresses.map((key, i) => {
      const token = tokens[key];
      const usd = (0,math/* e10 */.TB)(token.decimals).mulDiv(uiData.result[0].ethRate, balanceData.result[0][i].rate);

      const full = _objectSpread(_objectSpread(_objectSpread({}, token), balanceData.result[0][i]), {}, {
        usd
      });

      return _objectSpread(_objectSpread({}, token), {}, {
        usd,
        address: token.address,
        name: token.name,
        symbol: token.symbol,
        decimals: token.decimals,
        balance: token.address === weth ? uiData.result[0].ethBalance : balanceData.result[0][i].balance,
        bentoBalance: balanceData.result[0][i].bentoBalance,
        wallet: (0,kashi/* easyAmount */.bi)(token.address === weth ? uiData.result[0].ethBalance : balanceData.result[0][i].balance, full),
        bento: (0,kashi/* easyAmount */.bi)((0,bentobox/* toAmount */.s)(full, balanceData.result[0][i].bentoBalance), full)
      });
    }).filter(token => token.balance.gt('0') || token.bentoBalance.gt('0'));
  }, [uiData.loading, uiData.error, uiData.result, balanceData.loading, balanceData.error, balanceData.result, tokenAddresses, tokens, weth]);
}
function useBentoBalance(tokenAddress) {
  const {
    account
  } = useActiveWeb3React();
  const boringHelperContract = useBoringHelperContract();
  const bentoBoxContract = useBentoBoxContract();
  const tokenAddressChecksum = getAddress(tokenAddress);
  const tokenContract = useContract(tokenAddressChecksum ? tokenAddressChecksum : undefined, ERC20_ABI);
  const currentTransactionStatus = useTransactionStatus();
  const {
    0: balance,
    1: setBalance
  } = useState(); // const balanceData = useSingleCallResult(boringHelperContract, 'getBalances', [account, tokenAddresses])

  const fetchBentoBalance = useCallback(async () => {
    const balances = await (boringHelperContract === null || boringHelperContract === void 0 ? void 0 : boringHelperContract.getBalances(account, [tokenAddressChecksum]));
    const decimals = await (tokenContract === null || tokenContract === void 0 ? void 0 : tokenContract.decimals());
    const amount = BigNumber.from(balances[0].bentoShare).isZero() ? BigNumber.from(0) : BigNumber.from(balances[0].bentoBalance).mul(BigNumber.from(balances[0].bentoAmount)).div(BigNumber.from(balances[0].bentoShare));
    setBalance({
      value: amount,
      decimals: decimals
    });
  }, [account, tokenAddressChecksum, tokenContract, boringHelperContract]);
  useEffect(() => {
    if (account && bentoBoxContract && boringHelperContract && tokenContract) {
      fetchBentoBalance();
    }
  }, [account, bentoBoxContract, currentTransactionStatus, fetchBentoBalance, tokenContract, boringHelperContract]);
  return balance;
}
function useBentoMasterContractAllowed(masterContract, user) {
  const contract = (0,hooks_useContract/* useBentoBoxContract */.rO)();
  const inputs = (0,external_react_.useMemo)(() => [masterContract, user], [masterContract, user]);
  const allowed = (0,hooks/* useSingleCallResult */.Wk)(contract, 'masterContractApproved', inputs).result;
  return (0,external_react_.useMemo)(() => allowed ? allowed[0] : undefined, [allowed]);
}

/***/ })

};
;
//# sourceMappingURL=6430.js.map
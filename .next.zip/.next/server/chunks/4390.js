"use strict";
exports.id = 4390;
exports.ids = [4390];
exports.modules = {

/***/ 8561:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Dots)
/* harmony export */ });
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3289);
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _functions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7735);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);





function Dots({
  children = /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("span", {}),
  className
}) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.Fragment, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx((styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default()), {
      id: "106137454",
      children: [".dots.jsx-106137454::after{content:'.';}"]
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("span", {
      className: "jsx-106137454" + " " + ((0,_functions__WEBPACK_IMPORTED_MODULE_1__/* .classNames */ .AK)('after:inline-block dots after:animate-ellipsis after:w-4 after:text-left', className) || ""),
      children: children
    })]
  });
}

/***/ }),

/***/ 4596:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ DoubleCurrencyLogo)
/* harmony export */ });
/* harmony import */ var _CurrencyLogo__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1208);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _functions__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7735);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);





function DoubleCurrencyLogo({
  currency0,
  currency1,
  size = 16,
  className,
  logoClassName
}) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
    className: (0,_functions__WEBPACK_IMPORTED_MODULE_2__/* .classNames */ .AK)('flex items-center space-x-2', className),
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(_CurrencyLogo__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z, {
      className: logoClassName,
      currency: currency0,
      size: size.toString() + 'px'
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(_CurrencyLogo__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z, {
      className: logoClassName,
      currency: currency1,
      size: size.toString() + 'px'
    })]
  });
}

/***/ }),

/***/ 4390:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "W": () => (/* binding */ MinimalPositionCard),
/* harmony export */   "Z": () => (/* binding */ FullPositionCard)
/* harmony export */ });
/* harmony import */ var _heroicons_react_outline__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6049);
/* harmony import */ var _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6766);
/* harmony import */ var _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _functions_currency__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7553);
/* harmony import */ var _Column__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1898);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8532);
/* harmony import */ var _Button__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7603);
/* harmony import */ var _CurrencyLogo__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1208);
/* harmony import */ var _Dots__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8561);
/* harmony import */ var _DoubleLogo__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(4596);
/* harmony import */ var _hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8269);
/* harmony import */ var _hooks__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(9202);
/* harmony import */ var _lingui_react__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(2339);
/* harmony import */ var _lingui_react__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_lingui_react__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(6731);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _state_wallet_hooks__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(2319);
/* harmony import */ var _hooks_useTotalSupply__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(1274);
/* harmony import */ var _functions__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(7735);
/* harmony import */ var _headlessui_react__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(4025);
/* harmony import */ var _headlessui_react__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(_headlessui_react__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__);





















function MinimalPositionCard({
  pair,
  showUnwrapped = false,
  border
}) {
  const {
    i18n
  } = (0,_lingui_react__WEBPACK_IMPORTED_MODULE_12__.useLingui)();
  const {
    account
  } = (0,_hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_10__/* .useActiveWeb3React */ .a)();
  const currency0 = showUnwrapped ? pair.token0 : (0,_functions_currency__WEBPACK_IMPORTED_MODULE_3__/* .unwrappedToken */ .Bv)(pair.token0);
  const currency1 = showUnwrapped ? pair.token1 : (0,_functions_currency__WEBPACK_IMPORTED_MODULE_3__/* .unwrappedToken */ .Bv)(pair.token1);
  const {
    0: showMore,
    1: setShowMore
  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
  const userPoolBalance = (0,_state_wallet_hooks__WEBPACK_IMPORTED_MODULE_14__/* .useTokenBalance */ .mM)(account !== null && account !== void 0 ? account : undefined, pair.liquidityToken);
  const totalPoolTokens = (0,_hooks_useTotalSupply__WEBPACK_IMPORTED_MODULE_15__/* .useTotalSupply */ .A)(pair.liquidityToken);
  const poolTokenPercentage = !!userPoolBalance && !!totalPoolTokens && _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.JSBI.greaterThanOrEqual(totalPoolTokens.quotient, userPoolBalance.quotient) ? new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.Percent(userPoolBalance.quotient, totalPoolTokens.quotient) : undefined;
  const [token0Deposited, token1Deposited] = !!pair && !!totalPoolTokens && !!userPoolBalance && // this condition is a short-circuit in the case where useTokenBalance updates sooner than useTotalSupply
  _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.JSBI.greaterThanOrEqual(totalPoolTokens.quotient, userPoolBalance.quotient) ? [pair.getLiquidityValue(pair.token0, totalPoolTokens, userPoolBalance, false), pair.getLiquidityValue(pair.token1, totalPoolTokens, userPoolBalance, false)] : [undefined, undefined];
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.Fragment, {
    children: userPoolBalance && _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.JSBI.greaterThan(userPoolBalance.quotient, _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.JSBI.BigInt(0)) ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx("div", {
      className: "p-5 rounded bg-dark-800 text-high-emphesis",
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)(_Column__WEBPACK_IMPORTED_MODULE_4__/* .AutoColumn */ .Tz, {
        gap: 'md',
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx("div", {
          className: "text-lg",
          children: "Your Position"
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)("div", {
          className: "flex flex-col md:flex-row md:justify-between",
          children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)("div", {
            className: "flex items-center w-auto space-x-4",
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_DoubleLogo__WEBPACK_IMPORTED_MODULE_9__/* .default */ .Z, {
              currency0: pair.token0,
              currency1: pair.token1,
              size: 40
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)("div", {
              className: "text-2xl font-semibold",
              children: [currency0.symbol, "/", currency1.symbol]
            })]
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)("div", {
            className: "flex items-center mt-3 space-x-2 text-base md:mt-0",
            children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)("div", {
              children: [userPoolBalance ? userPoolBalance.toSignificant(4) : '-', " "]
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx("div", {
              className: "text-secondary",
              children: "Pool Tokens"
            })]
          })]
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)("div", {
          className: "flex flex-col w-full p-3 mt-3 space-y-1 text-sm rounded bg-dark-900 text-high-emphesis",
          children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)("div", {
            className: "flex justify-between",
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx("div", {
              children: i18n._(
              /*i18n*/
              i18n._("Your pool share"))
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx("div", {
              className: "font-bold",
              children: poolTokenPercentage ? poolTokenPercentage.toFixed(6) + '%' : '-'
            })]
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)("div", {
            className: "flex justify-between",
            children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)("div", {
              children: [currency0.symbol, ":"]
            }), token0Deposited ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)("div", {
              className: "flex space-x-2 font-bold",
              children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)("div", {
                children: [" ", token0Deposited === null || token0Deposited === void 0 ? void 0 : token0Deposited.toSignificant(6)]
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx("div", {
                className: "text-secondary",
                children: currency0.symbol
              })]
            }) : '-']
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)("div", {
            className: "flex justify-between",
            children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)("div", {
              children: [currency1.symbol, ":"]
            }), token1Deposited ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)("div", {
              className: "flex space-x-2 font-bold",
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx("div", {
                children: token1Deposited === null || token1Deposited === void 0 ? void 0 : token1Deposited.toSignificant(6)
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx("div", {
                className: "text-secondary",
                children: currency1.symbol
              })]
            }) : '-']
          })]
        })]
      })
    }) : null
  });
}
function FullPositionCard({
  pair,
  border,
  stakedBalance
}) {
  const {
    i18n
  } = (0,_lingui_react__WEBPACK_IMPORTED_MODULE_12__.useLingui)();
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_13__.useRouter)();
  const {
    account,
    chainId
  } = (0,_hooks_useActiveWeb3React__WEBPACK_IMPORTED_MODULE_10__/* .useActiveWeb3React */ .a)();
  const currency0 = (0,_functions_currency__WEBPACK_IMPORTED_MODULE_3__/* .unwrappedToken */ .Bv)(pair.token0);
  const currency1 = (0,_functions_currency__WEBPACK_IMPORTED_MODULE_3__/* .unwrappedToken */ .Bv)(pair.token1);
  const {
    0: showMore,
    1: setShowMore
  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
  const userDefaultPoolBalance = (0,_state_wallet_hooks__WEBPACK_IMPORTED_MODULE_14__/* .useTokenBalance */ .mM)(account !== null && account !== void 0 ? account : undefined, pair.liquidityToken);
  const totalPoolTokens = (0,_hooks_useTotalSupply__WEBPACK_IMPORTED_MODULE_15__/* .useTotalSupply */ .A)(pair.liquidityToken); // if staked balance balance provided, add to standard liquidity amount

  const userPoolBalance = stakedBalance ? userDefaultPoolBalance === null || userDefaultPoolBalance === void 0 ? void 0 : userDefaultPoolBalance.add(stakedBalance) : userDefaultPoolBalance;
  const poolTokenPercentage = !!userPoolBalance && !!totalPoolTokens && _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.JSBI.greaterThanOrEqual(totalPoolTokens.quotient, userPoolBalance.quotient) ? new _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.Percent(userPoolBalance.quotient, totalPoolTokens.quotient) : undefined;
  const [token0Deposited, token1Deposited] = !!pair && !!totalPoolTokens && !!userPoolBalance && // this condition is a short-circuit in the case where useTokenBalance updates sooner than useTotalSupply
  _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.JSBI.greaterThanOrEqual(totalPoolTokens.quotient, userPoolBalance.quotient) ? [pair.getLiquidityValue(pair.token0, totalPoolTokens, userPoolBalance, false), pair.getLiquidityValue(pair.token1, totalPoolTokens, userPoolBalance, false)] : [undefined, undefined];
  const backgroundColor = (0,_hooks__WEBPACK_IMPORTED_MODULE_11__/* .useColor */ .rd)(pair === null || pair === void 0 ? void 0 : pair.token0);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)("div", {
    className: "rounded bg-dark-800" // style={{ backgroundColor }}
    ,
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)(_Button__WEBPACK_IMPORTED_MODULE_6__/* .default */ .ZP, {
      variant: "empty",
      className: (0,_functions__WEBPACK_IMPORTED_MODULE_16__/* .classNames */ .AK)('flex items-center justify-between w-full px-4 py-6 cursor-pointer bg-dark-800 hover:bg-dark-700', showMore && '!bg-dark-700'),
      style: {
        boxShadow: 'none'
      },
      onClick: () => setShowMore(!showMore),
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)("div", {
        className: "flex items-center space-x-4",
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_DoubleLogo__WEBPACK_IMPORTED_MODULE_9__/* .default */ .Z, {
          currency0: currency0,
          currency1: currency1,
          size: 40
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx("div", {
          className: "text-xl font-semibold",
          children: !currency0 || !currency1 ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_Dots__WEBPACK_IMPORTED_MODULE_8__/* .default */ .Z, {
            children: i18n._(
            /*i18n*/
            i18n._("Loading"))
          }) : `${currency0.symbol}/${currency1.symbol}`
        })]
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)("div", {
        className: "flex items-center space-x-4",
        children: [i18n._(
        /*i18n*/
        i18n._("Manage")), showMore ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_heroicons_react_outline__WEBPACK_IMPORTED_MODULE_0__/* .ChevronUpIcon */ .g8U, {
          width: "20px",
          height: "20px",
          className: "ml-4"
        }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_heroicons_react_outline__WEBPACK_IMPORTED_MODULE_0__/* .ChevronDownIcon */ .v4q, {
          width: "20px",
          height: "20px",
          className: "ml-4"
        })]
      })]
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_17__.Transition, {
      show: showMore,
      enter: "transition-opacity duration-75",
      enterFrom: "opacity-0",
      enterTo: "opacity-100",
      leave: "transition-opacity duration-150",
      leaveFrom: "opacity-100",
      leaveTo: "opacity-0",
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)("div", {
        className: "p-4 space-y-4",
        children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)("div", {
          className: "px-4 py-4 space-y-1 text-sm rounded text-high-emphesis bg-dark-900",
          children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)("div", {
            className: "flex items-center justify-between",
            children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)("div", {
              children: [i18n._(
              /*i18n*/
              i18n._("Your total pool tokens")), ":"]
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx("div", {
              className: "font-semibold",
              children: userPoolBalance ? userPoolBalance.toSignificant(4) : '-'
            })]
          }), stakedBalance && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)("div", {
            className: "flex items-center justify-between",
            children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)("div", {
              children: [i18n._(
              /*i18n*/
              i18n._("Pool tokens in rewards pool")), ":"]
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx("div", {
              className: "font-semibold",
              children: stakedBalance.toSignificant(4)
            })]
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)("div", {
            className: "flex items-center justify-between",
            children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)("div", {
              children: [i18n._(
              /*i18n*/
              i18n._("Pooled {0}", {
                0: currency0 === null || currency0 === void 0 ? void 0 : currency0.symbol
              })), ":"]
            }), token0Deposited ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)("div", {
              className: "flex items-center space-x-2",
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx("div", {
                className: "font-semibold",
                children: token0Deposited === null || token0Deposited === void 0 ? void 0 : token0Deposited.toSignificant(6)
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_CurrencyLogo__WEBPACK_IMPORTED_MODULE_7__/* .default */ .Z, {
                size: "20px",
                currency: currency0
              })]
            }) : '-']
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)("div", {
            className: "flex items-center justify-between",
            children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)("div", {
              children: [i18n._(
              /*i18n*/
              i18n._("Pooled {0}", {
                0: currency1 === null || currency1 === void 0 ? void 0 : currency1.symbol
              })), ":"]
            }), token1Deposited ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)("div", {
              className: "flex items-center space-x-2",
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx("div", {
                className: "font-semibold ",
                children: token1Deposited === null || token1Deposited === void 0 ? void 0 : token1Deposited.toSignificant(6)
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_CurrencyLogo__WEBPACK_IMPORTED_MODULE_7__/* .default */ .Z, {
                size: "20px",
                currency: currency1
              })]
            }) : '-']
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)("div", {
            className: "flex items-center justify-between",
            children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)("div", {
              children: [i18n._(
              /*i18n*/
              i18n._("Your pool share")), ":"]
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx("div", {
              className: "font-semibold",
              children: poolTokenPercentage ? (poolTokenPercentage.toFixed(2) === '0.00' ? '<0.01' : poolTokenPercentage.toFixed(2)) + '%' : '-'
            })]
          })]
        }), userDefaultPoolBalance && _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_1__.JSBI.greaterThan(userDefaultPoolBalance.quotient, _constants__WEBPACK_IMPORTED_MODULE_5__/* .BIG_INT_ZERO */ .iV) && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsxs)("div", {
          className: "grid grid-cols-2 gap-4",
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_Button__WEBPACK_IMPORTED_MODULE_6__/* .default */ .ZP, {
            color: "blue",
            onClick: () => {
              router.push(`/add/${(0,_functions_currency__WEBPACK_IMPORTED_MODULE_3__/* .currencyId */ .Hh)(currency0)}/${(0,_functions_currency__WEBPACK_IMPORTED_MODULE_3__/* .currencyId */ .Hh)(currency1)}`);
            },
            children: i18n._(
            /*i18n*/
            i18n._("Add"))
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_18__.jsx(_Button__WEBPACK_IMPORTED_MODULE_6__/* .default */ .ZP, {
            color: "blue",
            onClick: () => {
              router.push(`/remove/${(0,_functions_currency__WEBPACK_IMPORTED_MODULE_3__/* .currencyId */ .Hh)(currency0)}/${(0,_functions_currency__WEBPACK_IMPORTED_MODULE_3__/* .currencyId */ .Hh)(currency1)}`);
            },
            children: i18n._(
            /*i18n*/
            i18n._("Remove"))
          })]
        })]
      })
    })]
  });
}

/***/ }),

/***/ 1274:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "A": () => (/* binding */ useTotalSupply)
/* harmony export */ });
/* harmony import */ var _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6766);
/* harmony import */ var _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _state_multicall_hooks__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(879);
/* harmony import */ var _useContract__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6435);


 // returns undefined if input token is undefined, or fails to get token contract,
// or contract total supply cannot be fetched

function useTotalSupply(token) {
  var _useSingleCallResult, _useSingleCallResult$;

  const contract = (0,_useContract__WEBPACK_IMPORTED_MODULE_2__/* .useTokenContract */ .Ib)(token !== null && token !== void 0 && token.isToken ? token.address : undefined, false);
  const totalSupply = (_useSingleCallResult = (0,_state_multicall_hooks__WEBPACK_IMPORTED_MODULE_1__/* .useSingleCallResult */ .Wk)(contract, 'totalSupply')) === null || _useSingleCallResult === void 0 ? void 0 : (_useSingleCallResult$ = _useSingleCallResult.result) === null || _useSingleCallResult$ === void 0 ? void 0 : _useSingleCallResult$[0];
  return token !== null && token !== void 0 && token.isToken && totalSupply ? _sushiswap_sdk__WEBPACK_IMPORTED_MODULE_0__.CurrencyAmount.fromRawAmount(token, totalSupply.toString()) : undefined;
}

/***/ })

};
;
//# sourceMappingURL=4390.js.map